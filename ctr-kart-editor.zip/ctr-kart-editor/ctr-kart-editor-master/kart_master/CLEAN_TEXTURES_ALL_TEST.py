import bpy
import os
from PIL import Image

# Coordenadas de Recorte
crop_data = {
    "Velo Chopper": [
        (8, 4, 28, 19),  # back_00
        (79, 69, 79, 59),  # back_01
        (18, 95, 18, 71),  # chair_01
        (52, 82, 52, 59),  # exhaust_pipe01
        (178, 53, 178, 42),  # floor_01
        (68, 19, 68, 4),  # front_1
        (59, 43, 59, 31),  # front_2
        (124, 29, 124, 3),  # front_3
        (149, 30, 149, 3),  # front_4
        (135, 128, 135, 98),  # front_05
        (101, 19, 101, 4),  # front_06
        (25, 57, 25, 32),  # front_7
        (173, 94, 173, 82),  # motortop_01
        (133, 82, 133, 68),  # motortop_02
        (79, 96, 79, 84),  # pipe_03
        (47, 108, 47, 104),  # shadow_01
        (176, 17, 176, 3),  # side_1
        (35, 19, 35, 3),  # side_02
        (142, 52, 142, 45),  # steeringwheel
        (102, 97, 102, 84),  # up_yellow
        (91, 44, 91, 36),  # left_right
    ],
    "Kart": [
        (35, 19, 35, 3),  # Front
        (70, 19, 70, 3),  # Back
        (98, 19, 98, 3),  # Bridge
        (28, 49, 28, 41),  # Floor
        (62, 47, 62, 43),  # red
        (98, 54, 98, 38),  # exhaust
        (39, 87, 39, 71),  # motortop
        (96, 87, 96, 71),  # side
        (62, 105, 62, 89),  # exhaust pipe
    ],
    "Kart Hi": [
        (365, 111, 365, 43),  # kart_top
        (176, 119, 176, 87),  # kart_front_side
        (350, 14, 350, 10),  # kart_front_bottom
        (259, 44, 259, 40),  # kart_front_02
        (272, 14, 272, 10),  # kart_front
        (66, 120, 66, 88),  # kart_floor
        (166, 58, 166, 10),  # kart_back_bottom
        (76, 58, 76, 10),  # kart_back_02
        (443, 167, 443, 119),  # exhaust_pipe_02
        (437, 37, 437, 5),  # exhaust_pipe_01
        (437, 93, 437, 61),  # exhaust_pipe_00
        (127, 161, 127, 157),  # metal_01
        (189, 161, 189, 157),  # metal_02
        (275, 161, 275, 161),  # metal_04
        (64, 167, 64, 149),  # top
        (273, 91, 273, 75),  # tube
        (258, 119, 258, 115),  # tube_02
    ]
}

template_names = {
    "Velo Chopper": [
        "back_00", "back_01", "chair_01", "exhaust_pipe01",
        "floor_01", "front_1", "front_2", "front_3",
        "front_4", "front_05", "front_06", "front_7",
        "motortop_01", "motortop_02", "pipe_03", "shadow_01",
        "side_1", "side_02", "steeringwheel", "up_yellow", "left_right"
    ],
    "Kart": [
        "Front", "Back", "Bridge", "Floor", "red",
        "exhaust", "motortop", "side", "exhaust pipe"
    ],
    "Kart Hi": [
        "kart_top", "kart_front_side", "kart_front_bottom",
        "kart_front_02", "kart_front", "kart_floor",
        "kart_back_bottom", "kart_back_02", "exhaust_pipe_02",
        "exhaust_pipe_01", "exhaust_pipe_00", "metal_01",
        "metal_02", "metal_04", "top", "tube", "tube_02"
    ]
}

# Recorte de Imágenes
def crop_image(image_path, coords):
    img = Image.open(image_path)
    left, upper, right, lower = coords
    if left < right and upper < lower:
        cropped_img = img.crop((left, upper, right, lower))
        return cropped_img
    else:
        raise ValueError(f"Coordenadas inválidas: {coords}")

# Procesamiento de Imágenes
def process_image(image_path, crop_coords, crop_name):
    image = os.path.join(image_path, "template013.png")
    if os.path.exists(image):
        cropped = crop_image(image, crop_coords)
        cropped.save(os.path.join(image_path, f"{crop_name}.png"))
        print(f"Guardado: {crop_name}.png en {image_path}")  # Confirmación de guardado
    else:
        print(f"Archivo no encontrado: {image}")

# Propiedades de la escena
class MyProperties(bpy.types.PropertyGroup):
    my_folder_path: bpy.props.StringProperty(name="Folder Path", subtype='DIR_PATH')
    selected_template: bpy.props.EnumProperty(
        name="Select Template",
        items=[
            ("KART", "Kart", ""),
            ("VELO_CHOPPER", "Velo Chopper", ""),
            ("KART_HI", "Kart Hi", ""),
        ],
    )

# Operador para Limpiar Texturas
class OT_CleanTextures(bpy.types.Operator):
    bl_idname = "object.clean_textures"
    bl_label = "Clean Textures"

    def execute(self, context):
        main_folder = context.scene.my_properties.my_folder_path
        selected_template = context.scene.my_properties.selected_template

        # Convertir a nombre legible
        selected_template_name = {
            "KART": "Kart",
            "VELO_CHOPPER": "Velo Chopper",
            "KART_HI": "Kart Hi"
        }[selected_template]

        if not os.path.exists(main_folder):
            self.report({'WARNING'}, "La carpeta no existe.")
            return {'CANCELLED'}

        crop_coords_list = crop_data[selected_template_name]
        template_names_list = template_names[selected_template_name]

        for root, dirs, files in os.walk(main_folder):
            template_files = [f for f in files if f.startswith("template") and f.endswith(".png")]
            for idx, file in enumerate(template_files):
                if idx < len(crop_coords_list):  # Asegúrate de que no se salga del índice
                    image_path = os.path.join(root, file)
                    crop_name = template_names_list[idx]
                    print(f"Recortando: {crop_name} usando {crop_coords_list[idx]}")  # Imprimir información del recorte
                    process_image(root, crop_coords_list[idx], crop_name)

                    # Eliminar otras imágenes en la carpeta
                    for other_file in files:
                        if not other_file.startswith("template"):
                            os.remove(os.path.join(root, other_file))
        
        return {'FINISHED'}

# Panel en la Interfaz de Blender
class PT_MainPanel(bpy.types.Panel):
    bl_label = "Limpieza de Texturas"
    bl_idname = "PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Clean Textures"

    def draw(self, context):
        layout = self.layout
        props = context.scene.my_properties
        
        layout.prop(props, "my_folder_path", text="Seleccionar Carpeta")
        layout.prop(props, "selected_template", text="Seleccionar Plantilla")
        layout.operator(OT_CleanTextures.bl_idname)

# Funciones de Registro y Anulación
def register():
    bpy.utils.register_class(MyProperties)
    bpy.types.Scene.my_properties = bpy.props.PointerProperty(type=MyProperties)
    bpy.utils.register_class(OT_CleanTextures)
    bpy.utils.register_class(PT_MainPanel)

def unregister():
    bpy.utils.unregister_class(PT_MainPanel)
    bpy.utils.unregister_class(OT_CleanTextures)
    del bpy.types.Scene.my_properties

if __name__ == "__main__":
    register()
